vim-config
==========

kodango's vim config repository
add press F4 by linuxliu 2016.12.26
